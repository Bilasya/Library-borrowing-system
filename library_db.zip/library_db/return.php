<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// Validate access
if (!isset($_GET['borrow_id'])) {
    die("Invalid access.");
}

$borrow_id = intval($_GET['borrow_id']); // Safer approach

// Get borrow data
$query = "SELECT br.*, b.title, b.id AS book_id FROM borrow br 
          JOIN books b ON br.book_id = b.id 
          WHERE br.id = '$borrow_id' AND br.user_id = '$user_id'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) === 0) {
    die("Borrow record not found.");
}

$data = mysqli_fetch_assoc($result);

// Check if return is late
$isLate = strtotime($data['return_date']) < time();
if ($isLate) {
    mysqli_query($conn, "UPDATE users SET status='banned' WHERE id='$user_id'");
    $_SESSION['error_message'] = "You are late returning the book! Your account has been suspended for 7 days.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $condition = $_POST['condition'];
    $actual_return_date = date('Y-m-d'); // Actual return date

    // Insert into return history
    $stmt = $conn->prepare("INSERT INTO return_history (user_id, book_id, borrow_date, return_date, `condition`) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        "iisss",
        $user_id,
        $data['book_id'],
        $data['borrow_date'],
        $actual_return_date,
        $condition
    );

    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    // Delete borrow record & update book quantity
    mysqli_query($conn, "DELETE FROM borrow WHERE id = '$borrow_id'");
    mysqli_query($conn, "UPDATE books SET quantity = quantity + 1 WHERE id = '{$data['book_id']}'");

    // Condition-based warning
    if ($condition === 'damaged' || $condition === 'lost') {
        $_SESSION['warning_message'] = "Please visit the library staff to resolve penalties related to a $condition book.";
    }

    $_SESSION['success_message'] = "The book '{$data['title']}' was successfully returned. Condition: $condition.";
    header("Location: history.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Return Book</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
  <h2>Return Book: <?= htmlspecialchars($data['title']) ?></h2>
  <?php if ($isLate): ?>
    <div class="alert alert-danger">⚠️ Your return is overdue! Your account will be suspended for 7 days.</div>
  <?php endif; ?>

  <form method="post">
    <div class="mb-3">
      <label for="condition" class="form-label">Book Condition</label>
      <select name="condition" id="condition" class="form-select" required>
        <option value="Baik">Good</option>
        <option value="Rusak">Damaged</option>
        <option value="Hilang">Lost</option>
        <option value="Lainnya">Others</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Submit Return</button>
    <a href="borrow.php" class="btn btn-secondary">Cancel</a>
  </form>
</body>
</html>
