<?php 
session_start();
include 'config.php';

// Handle Contact Us form submission
if (isset($_POST['submit_contact'])) {
    $user_id = $_SESSION['user']['id'];
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $query = "INSERT INTO contacts (user_id, message, created_at) VALUES ('$user_id', '$message', NOW())";

    if (mysqli_query($conn, $query)) {
        $_SESSION['contact_success'] = "Thank you for contacting us!";
    } else {
        $_SESSION['contact_error'] = "Failed to send message: " . mysqli_error($conn);
    }

    header("Location: aboutus.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us | PUSTAKA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
:root {
  --primary-color: #6a11cb; /* Ungu utama */
  --secondary-color: #2575fc;
  --accent-color: #ffc107;
  --light-bg: #f8f9fa;
  --dark-text: #343a40;
}

body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background-color: #f5f5f5;
}

.sidebar {
  width: 280px;
  background-color: white;
  height: 100vh;
  position: fixed;
  box-shadow: 2px 0 15px rgba(0,0,0,0.1);
  padding: 20px;
}

.sidebar h2 {
  color: var(--primary-color);
  text-align: center;
  margin-bottom: 30px;
  padding-bottom: 15px;
  border-bottom: 1px solid #eee;
}

.profile {
  text-align: center;
  margin-bottom: 30px;
}

.profile strong {
  color: var(--dark-text);
  display: block;
  margin-bottom: 5px;
}

.profile span {
  color: #6c757d;
  font-size: 0.9rem;
}

.sidebar ul {
  list-style: none;
  padding: 0;
}

.sidebar ul li a {
  display: flex;
  align-items: center;
  padding: 12px 15px;
  margin-bottom: 8px;
  border-radius: 8px;
  color: var(--primary-color); /* Warna ungu untuk teks link */
  text-decoration: none;
  transition: all 0.3s;
}

.sidebar ul li a:hover,
.sidebar ul li a.active {
  background-color: rgba(106, 17, 203, 0.1); /* Ungu muda background */
  color: var(--primary-color);
}

.sidebar ul li a i {
  margin-right: 10px;
  width: 20px;
  text-align: center;
  color: var(--primary-color); /* Ubah ikon jadi ungu */
}

.main-content {
  margin-left: 280px;
  padding: 30px;
}

.hero-section {
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  color: white;
  padding: 60px 40px;
  border-radius: 15px;
  margin-bottom: 30px;
  text-align: center;
}

.hero-section h1 {
  font-weight: 700;
  margin-bottom: 15px;
}

.about-content {
  background: white;
  border-radius: 15px;
  padding: 30px;
  margin-bottom: 30px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.about-content h3 {
  color: var(--primary-color);
  margin-bottom: 20px;
  position: relative;
  padding-bottom: 10px;
}

.about-content h3::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 50px;
  height: 3px;
  background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
}

.comment-section {
  background: white;
  border-radius: 15px;
  padding: 30px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.comment-form {
  margin-bottom: 40px;
}

.btn-primary {
  background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
  border: none;
  padding: 10px 25px;
  border-radius: 8px;
  font-weight: 500;
}

.comment-card {
  background: var(--light-bg);
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
}

.comment-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

.comment-date {
  font-size: 0.8rem;
  color: #6c757d;
}

@media (max-width: 992px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }

  .main-content {
    margin-left: 0;
  }
}
  </style>
</head>
<body>
<!-- Sidebar -->
<div class="sidebar">
      <h2>LIBRARY</h2>
      <div class="profile">
        <p><strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong><br><span>User</span></p>
      </div>
      <ul>
        <li>
          <a href="user_dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'user_dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i> Dashboard
          </a>
        </li>
        <li>
          <a href="books.php" class="<?= basename($_SERVER['PHP_SELF']) == 'books.php' ? 'active' : '' ?>">
            <i class="fas fa-book"></i> Books
          </a>
        </li>
        <li>
          <a href="borrow.php" class="<?= basename($_SERVER['PHP_SELF']) == 'borrow.php' ? 'active' : '' ?>">
            <i class="fas fa-bookmark"></i> Borrow
          </a>
        </li>
        <li>
          <a href="history.php" class="<?= basename($_SERVER['PHP_SELF']) == 'history.php' ? 'active' : '' ?>">
            <i class="fas fa-history"></i> History
          </a>
        </li>
        <li>
          <a href="aboutus.php" class="<?= basename($_SERVER['PHP_SELF']) == 'aboutus.php' ? 'active' : '' ?>">
            <i class="fas fa-info-circle"></i> About Us
          </a>
        </li>
        <li>
          <a href="logout.php" style="color:red;">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
  </div>


  <!-- Main Content -->
  <div class="main-content">
    <!-- Hero Section -->
    <div class="hero-section">
      <h1>About Our Library</h1>
      <p class="lead">Empowering knowledge through accessible reading</p>
    </div>
    
    <!-- About Content Section -->
    <div class="about-content">
      <h3>Our Services</h3>
      <p>At our library, we offer an easy and efficient book borrowing service to support your literacy and learning needs. Our borrowing system allows members to borrow a wide range of books, from textbooks and novels to academic references. By simply registering, you can access a variety of books and return them within the specified borrowing period. We are committed to providing efficient service and making it easier for all members to enrich their knowledge through access to quality books.</p>
      
      <h3 class="mt-5">Our Mission</h3>
      <p>To provide equal access to information, inspire a love of reading, and support lifelong learning for all members of our community. We strive to create an inclusive environment where everyone can explore, discover, and grow through our diverse collection of resources.</p>
      
      <h3 class="mt-5">Library Features</h3>
      <ul class="list-group list-group-flush mb-3">
        <li class="list-group-item d-flex align-items-center">
          <i class="fas fa-check-circle text-success me-3"></i>
          <span>Extensive collection of books across all genres</span>
        </li>
        <li class="list-group-item d-flex align-items-center">
          <i class="fas fa-check-circle text-success me-3"></i>
          <span>User-friendly online borrowing system</span>
        </li>
        <li class="list-group-item d-flex align-items-center">
          <i class="fas fa-check-circle text-success me-3"></i>
          <span>Comfortable reading spaces</span>
        </li>
        <li class="list-group-item d-flex align-items-center">
          <i class="fas fa-check-circle text-success me-3"></i>
          <span>Regular new book arrivals</span>
        </li>
      </ul>
    </div>
    
    <!-- Contact Us Section -->
    <div class="comment-section">
      <h3>Contact Us</h3>

      <?php if(isset($_SESSION['contact_success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?= $_SESSION['contact_success'] ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['contact_success']); endif; ?>
        
      <?php if(isset($_SESSION['contact_error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <?= $_SESSION['contact_error'] ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['contact_error']); endif; ?>

      <form method="POST" class="comment-form">
        <div class="mb-3">
          <label for="message" class="form-label">Your Message</label>
          <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
        </div>
        <button type="submit" name="submit_contact" class="btn btn-primary">
          <i class="fas fa-paper-plane me-2"></i> Send Message
        </button>
      </form>
      <hr class="my-4">
<div>
  <p><strong>Phone:</strong> +62 812-3456-7890</p>
  <p><strong>Email:</strong> pustaka.support@example.com</p>
</div>

    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
