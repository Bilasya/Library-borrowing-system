<?php  
session_start();
include 'config.php';

// Hanya admin yang bisa akses
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Ambil semua pesan contact us
$query = "SELECT contacts.*, users.name, users.email 
          FROM contacts 
          JOIN users ON contacts.user_id = users.id 
          ORDER BY contacts.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin | About Us Messages</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    body {
      background-color: #f5f5f5;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .sidebar {
      width: 280px;
      background-color: white;
      height: 100vh;
      position: fixed;
      box-shadow: 2px 0 15px rgba(0,0,0,0.1);
      padding: 20px;
    }
    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 1px solid #eee;
    }
    .profile {
      text-align: center;
      margin-bottom: 30px;
    }
    .profile strong {
      color: #343a40;
      display: block;
      margin-bottom: 5px;
    }
    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }
    .sidebar ul {
      list-style: none;
      padding: 0;
    }
    .sidebar ul li a {
      display: flex;
      align-items: center;
      padding: 12px 15px;
      margin-bottom: 8px;
      border-radius: 8px;
      color: #6a11cb;
      text-decoration: none;
      transition: all 0.3s;
    }
    .sidebar ul li a:hover,
    .sidebar ul li a.active {
      background-color: rgba(106, 17, 203, 0.1);
      color: #6a11cb;
    }
    .sidebar ul li a i {
      margin-right: 10px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }
    .main-content {
      margin-left: 280px;
      padding: 30px;
    }
    .card {
      background: white;
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    .message-item {
      background-color: #f8f9fa;
      padding: 20px;
      border-radius: 10px;
      margin-bottom: 20px;
    }
    .message-header {
      display: flex;
      justify-content: space-between;
    }
    .message-header h5 {
      margin: 0;
    }
    .message-date {
      font-size: 0.85rem;
      color: #6c757d;
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2>LIBRARY</h2>
  <div class="profile">
    <p><strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong><br><span>Admin</span></p>
  </div>
        <ul>
    <li><a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
    <li><a href="admin_books.php" ><i class="fas fa-book"></i> Books</a></li>
    <li><a href="manage.php"><i class="fas fa-users-cog"></i> Manage Users</a></li>
    <li><a href="admin_aboutus.php" class="active"><i class="fas fa-info-circle"></i> About Us</a></li>
    <li><a href="logout.php" style="color:red;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  </ul>
</div>

<!-- Main Content -->
<div class="main-content">
  <h2 class="mb-4">User Messages from About Us</h2>

  <div class="card">
    <?php if (mysqli_num_rows($result) > 0): ?>
      <?php while($row = mysqli_fetch_assoc($result)): ?>
        <div class="message-item">
          <div class="message-header">
            <h5><?= htmlspecialchars($row['name']) ?> (<?= htmlspecialchars($row['email']) ?>)</h5>
            <span class="message-date"><?= $row['created_at'] ?></span>
          </div>
          <p class="mt-2"><?= nl2br(htmlspecialchars($row['message'])) ?></p>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No messages have been submitted yet.</p>
    <?php endif; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
