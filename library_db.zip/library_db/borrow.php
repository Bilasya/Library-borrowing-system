<?php  
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Process book borrowing
if (isset($_GET['book_id'])) {
    $book_id = $_GET['book_id'];
    $user_id = $_SESSION['user']['id'];
    
    // Get book quantity
    $book_query = "SELECT quantity FROM books WHERE id = '$book_id'";
    $book_result = mysqli_query($conn, $book_query);
    
    if (!$book_result) {
        die("Query error: " . mysqli_error($conn));
    }
    
    $book_data = mysqli_fetch_assoc($book_result);

    if ($book_data && $book_data['quantity'] > 0) {
        // Calculate dates (borrow date + 14 days)
        $borrow_date = date('Y-m-d');
        $return_date = date('Y-m-d', strtotime('+14 days'));

        // Insert borrow record
        $borrow_query = "INSERT INTO borrow (user_id, book_id, borrow_date, return_date) 
                         VALUES ('$user_id', '$book_id', '$borrow_date', '$return_date')";
                             
        if (mysqli_query($conn, $borrow_query)) {
            // Update book quantity
            $update_quantity_query = "UPDATE books SET quantity = quantity - 1 WHERE id = '$book_id'";
            mysqli_query($conn, $update_quantity_query);

            $_SESSION['reminder'] = true;
            
            // Redirect to avoid resubmission
            header("Location: borrow.php");
            exit;
        } else {
            $_SESSION['error_message'] = 'Failed to borrow the book: ' . mysqli_error($conn);
        }
    } else {
        $_SESSION['error_message'] = 'Sorry, this book is out of stock.';
    }
}

// Process book return
if (isset($_GET['return'])) {
    $borrow_id = $_GET['return'];
    $user_id = $_SESSION['user']['id'];
    
    // Get borrow record with book information
    $check_query = "SELECT b.id as book_id, b.title FROM borrow br 
                   JOIN books b ON br.book_id = b.id 
                   WHERE br.id = '$borrow_id' AND br.user_id = '$user_id'";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) > 0) {
        $borrow_data = mysqli_fetch_assoc($check_result);
        $book_id = $borrow_data['book_id'];
        
// Ambil informasi pinjaman sebelum dihapus
$borrow_info_query = "SELECT * FROM borrow WHERE id = '$borrow_id'";
$borrow_info_result = mysqli_query($conn, $borrow_info_query);
$borrow_info = mysqli_fetch_assoc($borrow_info_result);
$borrow_date = $borrow_info['borrow_date'];

// Tanggal aktual pengembalian
$return_date = date('Y-m-d');

// Simpan ke return_history
$insert_history_query = "INSERT INTO return_history (user_id, book_id, borrow_date, return_date) 
                         VALUES ('$user_id', '$book_id', '$borrow_date', '$return_date')";
mysqli_query($conn, $insert_history_query);

// Hapus dari borrow
$delete_query = "DELETE FROM borrow WHERE id = '$borrow_id'";
if (mysqli_query($conn, $delete_query)) {
    // Update jumlah buku
    $update_query = "UPDATE books SET quantity = quantity + 1 WHERE id = '$book_id'";
    mysqli_query($conn, $update_query);

    $_SESSION['success_message'] = "Book '".$borrow_data['title']."' returned successfully!";
    header("Location: borrow.php");
    exit;
} else {
    $_SESSION['error_message'] = "Failed to return book: " . mysqli_error($conn);
}
    }
}

// Fetch user's borrowed books
$user_id = $_SESSION['user']['id'];
$query = "SELECT b.title, b.author, br.borrow_date, br.return_date, br.id AS borrow_id 
          FROM borrow br 
          JOIN books b ON br.book_id = b.id 
          WHERE br.user_id = '$user_id'";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query error: " . mysqli_error($conn));
}

// Delete borrow history
if (isset($_GET['delete'])) {
    $borrow_id = $_GET['delete'];
    $delete_query = "DELETE FROM borrow WHERE id = $borrow_id AND return_date < CURDATE()";
    $delete_result = mysqli_query($conn, $delete_query);
    if ($delete_result) {
        $_SESSION['success_message'] = "Borrow record deleted successfully.";
        header("Location: borrow.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to delete borrow record.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Your Borrowed Books</title>
  <link rel="stylesheet" href="books.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
   /* Sidebar Styles */
   .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }
    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }
    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }
    .profile p {
      margin: 0;
    }
    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }
    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }
    .sidebar ul li {
      margin: 8px 0;
    }
    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }
    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }
    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }
    .sidebar ul li a[style*="color:red"]:hover {
      background-color: #ffe6e6 !important;
    }
    .main {
      margin-left: 270px;
      padding: 20px;
    }
    .table {
      background-color: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    .table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }
      .main {
        margin-left: 0;
      }
  }
  </style>
</head>
<body>
  <!-- Reminder Modal -->
  <div class="modal fade" id="reminderModal" tabindex="-1" aria-labelledby="reminderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content rounded-4">
        <div class="modal-header bg-warning-subtle">
          <h5 class="modal-title" id="reminderModalLabel">📌 Book Borrowing Reminder</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ol>
            <li><strong>Books must be returned in good condition</strong> (no scribbles, folds, or physical damage).</li>
            <li><strong>Return the book by the specified due date.</strong> Late returns will result in a <span class="text-danger">7-day account suspension.</span></li>
            <li><strong>Lost books</strong> will incur a fine equal to the book's original price.</li>
            <li>Please double-check the book carefully before returning it. Library staff will inspect the book's condition.</li>
            <li><strong>Do not borrow more than the available stock.</strong></li>
          </ol>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-bs-dismiss="modal">I Understand</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Show reminder modal if session is set -->
  <?php if (isset($_SESSION['reminder'])): ?>
  <script>
    const reminderModal = new bootstrap.Modal(document.getElementById('reminderModal'));
    reminderModal.show();
  </script>
  <?php unset($_SESSION['reminder']); endif; ?>

  <!-- Show success/error messages -->
  <?php if (isset($_SESSION['success_message'])): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= $_SESSION['success_message'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <?php unset($_SESSION['success_message']); endif; ?>

  <?php if (isset($_SESSION['error_message'])): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?= $_SESSION['error_message'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <?php unset($_SESSION['error_message']); endif; ?>

  <div class="mycontainer">
<!-- Sidebar -->
<div class="sidebar">
      <h2>LIBRARY</h2>
      <div class="profile">
        <p><strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong><br><span>User</span></p>
      </div>
      <ul>
        <li>
          <a href="user_dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'user_dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i> Dashboard
          </a>
        </li>
        <li>
          <a href="books.php" class="<?= basename($_SERVER['PHP_SELF']) == 'books.php' ? 'active' : '' ?>">
            <i class="fas fa-book"></i> Books
          </a>
        </li>
        <li>
          <a href="borrow.php" class="<?= basename($_SERVER['PHP_SELF']) == 'borrow.php' ? 'active' : '' ?>">
            <i class="fas fa-bookmark"></i> Borrow
          </a>
        </li>
        <li>
          <a href="history.php" class="<?= basename($_SERVER['PHP_SELF']) == 'history.php' ? 'active' : '' ?>">
            <i class="fas fa-history"></i> History
          </a>
        </li>
        <li>
          <a href="aboutus.php" class="<?= basename($_SERVER['PHP_SELF']) == 'aboutus.php' ? 'active' : '' ?>">
            <i class="fas fa-info-circle"></i> About Us
          </a>
        </li>
        <li>
          <a href="logout.php" style="color:red;">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
    </div>


    <!-- Main Content -->
    <div class="main p-4">
      <h1 class="mb-4">Your Borrowed Books</h1>

      <table class="table table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Title</th>
            <th>Author</th>
            <th>Borrow Date</th>
            <th>Return Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 1;
          if (mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                $canDelete = (strtotime($row['return_date']) < time()) ? true : false;
                $canReturn = (strtotime($row['return_date']) >= time()) ? true : false;
                echo "<tr>
                  <td>$no</td>
                  <td>{$row['title']}</td>
                  <td>{$row['author']}</td>
                  <td>{$row['borrow_date']}</td>
                  <td>{$row['return_date']}</td>
                  <td>";
                if ($canDelete) {
                  echo "<a href='?delete={$row['borrow_id']}' class='btn btn-danger btn-sm'>Delete</a>";
                } elseif ($canReturn) {
                  $isLate = strtotime($row['return_date']) < time();
                  $btnClass = $isLate ? 'btn-danger' : 'btn-success';
                  $btnText = 'Return';
                  echo "<a href='return.php?borrow_id={$row['borrow_id']}' class='btn $btnClass btn-sm'>$btnText</a>";
                }
                echo "</td>
                </tr>";
                $no++;
              }
          } else {
              echo "<tr><td colspan='6'>No borrowed books found.</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>