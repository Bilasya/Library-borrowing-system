<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config.php';

$register_error = '';
$register_success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    // Validasi role
    if (!in_array($role, ['user', 'admin'])) {
        $register_error = "Invalid role.";
    } else {
        // Cek apakah email sudah terdaftar
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $register_error = "Email is already registered.";
        } else {
            // Insert data ke tabel users
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $password, $role);
            if ($stmt->execute()) {
                $register_success = "Registration successful! <a href='login.php'>Click here to login</a>.";
            } else {
                $register_error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Register - The Quiet Library</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background: url('perpus.jpg') no-repeat center center fixed;
            background-size: 120%;
        }

        header {
            background-color: #3f3f3f;
            padding: 20px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 25px;
            font-size: 16px;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #ffcc00;
        }

        .container {
            height: calc(100vh - 80px);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .register-box {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(8px);
            border-radius: 12px;
            padding: 30px;
            width: 300px;
            color: white;
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
        }

        .register-box h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .register-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 6px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .register-box input::placeholder {
            color: #ccc;
        }

        .register-box input:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 0.3);
        }

        .register-box button {
            width: 100%;
            padding: 10px;
            background: #6a0dad;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        .register-box button:hover {
            background: #5a0099;
        }

        .register-box .error {
            color: #ff4d4d;
            font-size: 0.9em;
            text-align: center;
        }

        .register-box .success {
            color: lightgreen;
            font-size: 0.9em;
            text-align: center;
        }

        .login-link {
            text-align: center;
            margin-top: 10px;
            font-size: 14px;
        }

        .login-link a {
            color: #ffc107;
            text-decoration: none;
            font-weight: 600;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">The Quiet Library</div>
        <nav></nav>
    </header>

    <div class="container">
        <div class="register-box">
            <h2>Register</h2>
            <?php if ($register_error): ?>
                <p class="error"><?= $register_error ?></p>
            <?php endif; ?>
            <?php if ($register_success): ?>
                <p class="success"><?= $register_success ?></p>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="text" name="name" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <select name="role" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
                <button type="submit" name="register">Register</button>
            </form>
            <div class="login-link">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </div>
    </div>
</body>
</html>
