<?php
session_start();
include 'config.php';

$login_error = ''; // Variabel untuk menyimpan pesan error

// Proses login ketika form dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil dan bersihkan input
    $email = trim(mysqli_real_escape_string($conn, $_POST['email']));
    $password = trim($_POST['password']);

    // Validasi input
    if (empty($email) || empty($password)) {
        $login_error = "Email dan password harus diisi!";
    } else {
        // Cari user berdasarkan email saja
        $query = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $query);

        if (!$result) {
            die("Query error: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);

            // Verifikasi password
            if (password_verify($password, $user['password'])) {

if ($user && password_verify($password, $user['password'])) {
    // Tambahkan pengecekan banned
    if (!is_null($user['banned_at'])) {
        echo "<script>alert('Akun ini sedang dibanned hingga 7 hari sejak tanggal {$user['banned_at']}'); window.location='login.php';</script>";
        exit;
    }

    // Login berhasil
    $_SESSION['user'] = $user;
    header("Location: dashboard.php");
    exit;
}

                // Set session data
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ];

                // Redirect berdasarkan role
                if ($user['role'] == 'admin') {
                    header("Location: admin_dashboard.php");
                    exit;
                } elseif ($user['role'] == 'user') {
                    header("Location: user_dashboard.php");
                    exit;
                } else {
                    // Role tidak valid
                    $login_error = "Akses ditolak: Role tidak valid";
                    unset($_SESSION['user']);
                }
            } else {
                $login_error = "Email atau password salah!";
            }
        } else {
            $login_error = "Email atau password salah!";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - The Quiet Library</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
    }

    body {
      background: url('perpus.jpg') no-repeat center center fixed;
      background-size: 120%;
    }

    header {
      background-color: #3f3f3f;
      padding: 20px 50px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: white;
    }

    .logo {
      font-size: 24px;
      font-weight: bold;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin-left: 25px;
      font-size: 16px;
      transition: color 0.3s;
    }

    nav a:hover {
      color: #ffcc00;
    }

    .container {
      height: calc(100vh - 80px);
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .form-box {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      padding: 40px;
      border-radius: 12px;
      width: 360px;
      color: white;
      box-shadow: 0 0 20px rgba(0,0,0,0.3);
    }

    .form-box h2 {
      text-align: center;
      margin-bottom: 25px;
    }

    .form-box input {
      width: 100%;
      padding: 12px 15px;
      margin: 12px 0;
      border: none;
      border-radius: 8px;
      background-color: rgba(255, 255, 255, 0.2);
      color: white;
      font-size: 14px;
    }

    .form-box input::placeholder {
      color: #ccc;
    }

    .form-box input:focus {
      outline: none;
      background-color: rgba(255, 255, 255, 0.3);
    }

    .form-box button {
      width: 100%;
      padding: 12px;
      background-color: #6a0dad;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      margin-top: 10px;
    }

    .form-box button:hover {
      background-color: #5a0099;
    }

    .form-box .error {
      color: #ff4d4d;
      font-size: 0.9em;
      text-align: center;
    }

    .form-box .switch-link {
      text-align: center;
      margin-top: 15px;
      font-size: 14px;
    }

    .form-box .switch-link a {
      color: #ffc107;
      text-decoration: none;
      font-weight: 600;
    }

    .form-box .switch-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">The Quiet Library</div>
  </header>

  <div class="container">
    <div class="form-box">
      <h2>Login</h2>
      <?php 
      if ($login_error): ?>
        <p class="error"><?= $login_error ?></p>
      <?php endif; ?>
      <form action="" method="POST">
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Login</button>
      </form>
      <div class="switch-link">
        Don't have an account? <a href="register.php">Register</a>
      </div>
    </div>
  </div>
</body>
</html>
