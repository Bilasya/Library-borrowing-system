<?php
session_start();
include 'config.php';

// Cek jika pengguna sudah login dan merupakan admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

// Proses hapus buku jika ada parameter delete
if (isset($_GET['delete'])) {
  $delete_id = intval($_GET['delete']);
  mysqli_query($conn, "DELETE FROM books WHERE id = $delete_id");
  header("Location: admin_books.php?message=Book deleted");
  exit;
}

// Fetch semua buku
$query = "SELECT * FROM books";
$result = mysqli_query($conn, $query);
if (!$result) {
  die("Query error: " . mysqli_error($conn));
}

$admin_name = $_SESSION['user']['name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Books</title>
  <link rel="stylesheet" href="books.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Sidebar Styles */
    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }
    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }
    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }
    .profile p {
      margin: 0;
    }
    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }
    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }
    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }
    .sidebar ul li {
      margin: 8px 0;
    }
    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }
    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }
    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }
    .sidebar ul li a[style*="color:red"]:hover {
      background-color: #ffe6e6 !important;
    }
    .main {
      margin-left: 270px;
      padding: 20px;
    }
    .table {
      background-color: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    .table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }
      .main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2>LIBRARY</h2>
  <div class="profile">
    <p><strong>Welcome, <?= $admin_name ?>!</strong><br><span>Administrator</span></p>
  </div>

  <ul>
    <li><a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
    <li><a href="admin_books.php" class="active"><i class="fas fa-book"></i> Books</a></li>
    <li><a href="manage.php"><i class="fas fa-users-cog"></i> Manage Users</a></li>
    <li><a href="admin_aboutus.php"><i class="fas fa-info-circle"></i> About Us</a></li>
    <li><a href="logout.php" style="color:red;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  </ul>
</div>

<!-- Main Content -->
<div class="main p-4">
  <h1 class="mb-4">Books Management</h1>

  <?php if (isset($_GET['message'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['message']) ?></div>
  <?php endif; ?>

  <a href="add_book.php" class="btn btn-success mb-4">Add Book</a>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>No</th>
        <th>Title</th>
        <th>Author</th>
        <th>Stock</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>$no</td>
                <td>{$row['title']}</td>
                <td>{$row['author']}</td>
                <td>{$row['quantity']}</td>
                <td>
                  <a href='edit_book.php?id={$row['id']}' class='btn btn-warning btn-sm'><i class='fas fa-edit'></i> Edit</a>
                  <a href='admin_books.php?delete={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this book?\")'><i class='fas fa-trash'></i> Delete</a>
                </td>
              </tr>";
        $no++;
      }
      ?>
    </tbody>
  </table>
</div>

</body>
</html>
