<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Get user information
$user_id = $_SESSION['user']['id'];
$user_name = htmlspecialchars($_SESSION['user']['name']);

// Get stats for dashboard
$books_query = "SELECT COUNT(*) as total_books FROM books";
$books_result = mysqli_query($conn, $books_query);
$total_books = mysqli_fetch_assoc($books_result)['total_books'];

$borrowed_query = "SELECT COUNT(*) as borrowed_books FROM borrow WHERE user_id = '$user_id'";
$borrowed_result = mysqli_query($conn, $borrowed_query);
$borrowed_books = mysqli_fetch_assoc($borrowed_result)['borrowed_books'];

$recent_books_query = "SELECT b.title, b.author, br.borrow_date, br.return_date 
                      FROM borrow br 
                      JOIN books b ON br.book_id = b.id 
                      WHERE br.user_id = '$user_id'
                      ORDER BY br.borrow_date DESC 
                      LIMIT 3";
$recent_books_result = mysqli_query($conn, $recent_books_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Dashboard | PUSTAKA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Sidebar Styles - Consistent with other pages */
    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }
    
    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }
    
    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }
    
    .profile p {
      margin: 0;
    }
    
    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }
    
    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }
    
    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }
    
    .sidebar ul li {
      margin: 8px 0;
    }
    
    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    
    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }
    
    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }
    
    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }
    
    .sidebar ul li a[style*="color:red"]:hover {
      background-color: #ffe6e6 !important;
    }
    
    /* Main Content */
    .main {
      margin-left: 270px;
      padding: 20px;
    }
    
    /* Dashboard Cards */
    .dashboard-card {
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
      transition: transform 0.3s ease;
    }
    
    .dashboard-card:hover {
      transform: translateY(-5px);
    }
    
    .card-books {
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
      color: white;
    }
    
    .card-borrowed {
      background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
      color: white;
    }
    
    .card-recent {
      background: linear-gradient(135deg, #f46b45 0%, #eea849 100%);
      color: white;
    }
    
    .card-icon {
      font-size: 2.5rem;
      margin-bottom: 15px;
    }
    
    /* Recent Books Table */
    .recent-table {
      background-color: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .recent-table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
      }
      
      .main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>
  <div class="mycontainer">
<!-- Sidebar -->
<div class="sidebar">
      <h2>LIBRARY</h2>
      <div class="profile">
        <p><strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong><br><span>User</span></p>
      </div>
      <ul>
        <li>
          <a href="user_dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'user_dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i> Dashboard
          </a>
        </li>
        <li>
          <a href="books.php" class="<?= basename($_SERVER['PHP_SELF']) == 'books.php' ? 'active' : '' ?>">
            <i class="fas fa-book"></i> Books
          </a>
        </li>
        <li>
          <a href="borrow.php" class="<?= basename($_SERVER['PHP_SELF']) == 'borrow.php' ? 'active' : '' ?>">
            <i class="fas fa-bookmark"></i> Borrow
          </a>
        </li>
        <li>
          <a href="history.php" class="<?= basename($_SERVER['PHP_SELF']) == 'history.php' ? 'active' : '' ?>">
            <i class="fas fa-history"></i> History
          </a>
        </li>
        <li>
          <a href="aboutus.php" class="<?= basename($_SERVER['PHP_SELF']) == 'aboutus.php' ? 'active' : '' ?>">
            <i class="fas fa-info-circle"></i> About Us
          </a>
        </li>
        <li>
          <a href="logout.php" style="color:red;">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
  </div>


    <!-- Main Content -->
    <div class="main p-4">
      <h1 class="mb-4">User Dashboard</h1>
      
      <!-- Stats Cards -->
      <div class="row">
        <div class="col-md-4">
          <div class="dashboard-card card-books">
            <div class="card-icon">
              <i class="fas fa-book-open"></i>
            </div>
            <h3><?= $total_books ?></h3>
            <p>Total Books Available</p>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="dashboard-card card-borrowed">
            <div class="card-icon">
              <i class="fas fa-bookmark"></i>
            </div>
            <h3><?= $borrowed_books ?></h3>
            <p>Your Borrowed Books</p>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="dashboard-card card-recent">
            <div class="card-icon">
              <i class="fas fa-history"></i>
            </div>
            <h3>Recent</h3>
            <p>Your Last 3 Borrows</p>
          </div>
        </div>
      </div>
      
      <!-- Recent Borrowed Books -->
      <div class="mt-5">
        <h3 class="mb-4">Recently Borrowed Books</h3>
        <?php if(mysqli_num_rows($recent_books_result) > 0): ?>
          <div class="table-responsive recent-table">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Borrow Date</th>
                  <th>Return Date</th>
                </tr>
              </thead>
              <tbody>
                <?php while($book = mysqli_fetch_assoc($recent_books_result)): ?>
                  <tr>
                    <td><?= htmlspecialchars($book['title']) ?></td>
                    <td><?= htmlspecialchars($book['author']) ?></td>
                    <td><?= $book['borrow_date'] ?></td>
                    <td><?= $book['return_date'] ?></td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="alert alert-info">
            You haven't borrowed any books yet. <a href="books.php" class="alert-link">Browse our collection</a> to get started!
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>