<?php
session_start();
include 'config.php';

// Hanya admin yang boleh akses
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Pastikan ada ID yang diterima dari URL
if (isset($_GET['id'])) {
    $book_id = $_GET['id'];

    // Query untuk menghapus buku berdasarkan ID
    $query = "DELETE FROM books WHERE id = $book_id";

    if (mysqli_query($conn, $query)) {
        // Jika penghapusan berhasil, alihkan ke halaman daftar buku
        header("Location: books.php?message=Book deleted successfully");
    } else {
        // Jika terjadi kesalahan, tampilkan pesan error
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // Jika tidak ada ID yang diberikan, alihkan kembali ke halaman daftar buku
    header("Location: books.php");
}

mysqli_close($conn);
?>
