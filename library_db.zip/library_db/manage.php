<?php 
session_start();
include 'config.php';

// Akses hanya untuk admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Unban otomatis jika sudah lebih dari 7 hari
mysqli_query($conn, "UPDATE users SET banned_at = NULL WHERE banned_at IS NOT NULL AND banned_at <= NOW() - INTERVAL 7 DAY");


// Ban user
if (isset($_GET['ban'])) {
    $id = $_GET['ban'];
    $query = "UPDATE users SET banned_at = NOW() WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        echo "User ID $id berhasil diban. <a href='manage.php'>Kembali ke Manage Users</a>";
    } else {
        die("Gagal memban user: " . mysqli_error($conn));
    }
    exit;
}


// Unban user
if (isset($_GET['unban'])) {
    $id = $_GET['unban'];
    mysqli_query($conn, "UPDATE users SET banned_at = NULL WHERE id = '$id'");
    header("Location: manage.php");
    exit;
}

$users = mysqli_query($conn, "SELECT * FROM users WHERE role != 'admin'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Users</title>
  <link rel="stylesheet" href="books.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }

    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }

    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }

    .profile p {
      margin: 0;
    }

    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }

    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }

    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .sidebar ul li {
      margin: 8px 0;
    }

    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }

    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }

    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }

    .main {
      margin-left: 270px;
      padding: 20px;
    }

    .table {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }

    .table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }
  </style>
</head>
<body>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2>LIBRARY</h2>
  <div class="profile">
    <p><strong>Halo, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</strong><br><span>Admin</span></p>
  </div>
  <ul>
  <ul>
    <li><a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
    <li><a href="admin_books.php"><i class="fas fa-book"></i> Books</a></li>
    <li><a href="manage.php" class="active"><i class="fas fa-users-cog"></i> Manage Users</a></li>
    <li><a href="admin_aboutus.php"><i class="fas fa-info-circle"></i> About Us</a></li>
    <li><a href="logout.php" style="color:red;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  </ul>
</div>

  <div class="main">
    <h1 class="mb-4">Manage Users</h1>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>No</th>
          <th>Name</th>
          <th>Email</th>
          <th>Banned At</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $no = 1;
        while ($row = mysqli_fetch_assoc($users)) {
            $isBanned = false;

            if (!empty($row['banned_at'])) {
                $banExpired = strtotime($row['banned_at']) <= strtotime('-7 days');
                $isBanned = !$banExpired;
            }

            $status = $isBanned ? "<span class='text-danger'>BANNED</span>" : "<span class='text-success'>Active</span>";
            echo "<tr>
                <td>$no</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>" . ($row['banned_at'] ?? '-') . "</td>
                <td>$status</td>
                <td>";

            if ($isBanned) {
                echo "<button class='btn btn-secondary btn-sm' disabled>Banned</button>";
            } else {
                echo "<a href='?ban={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Apakah kamu yakin ingin mem-banned user ini selama 7 hari?\")'>Ban</a>";
            }

            echo "</td></tr>";
            $no++;
        }

        ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
