<?php 
session_start();
include 'config.php';

// Hanya admin yang boleh akses
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Pastikan ada ID yang diterima dari URL
if (isset($_GET['id'])) {
    $book_id = intval($_GET['id']);

    // Ambil data buku berdasarkan ID
    $query = "SELECT * FROM books WHERE id = $book_id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $book = mysqli_fetch_assoc($result);
    } else {
        echo "Book not found.";
        exit;
    }
} else {
    echo "No book ID provided.";
    exit;
}

// Proses update data buku jika form di-submit
if (isset($_POST['submit'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $genre = mysqli_real_escape_string($conn, $_POST['genre']);
    $quantity = intval($_POST['qty']);  // Ambil nilai qty

    $update_query = "UPDATE books SET 
                        title = '$title', 
                        author = '$author', 
                        genre = '$genre', 
                        quantity = $quantity 
                     WHERE id = $book_id";  

    if (mysqli_query($conn, $update_query)) {
        header("Location: admin_books.php?message=Book updated successfully");
        exit;
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Users</title>
  <link rel="stylesheet" href="books.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      height: 100vh;
      padding: 20px;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }

    .sidebar h2 {
      color: #6a11cb;
      text-align: center;
      margin-top: 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 1.8rem;
    }

    .profile {
      text-align: center;
      margin: 25px 0;
      padding-bottom: 20px;
      border-bottom: 1px solid #e0e0e0;
    }

    .profile p {
      margin: 0;
    }

    .profile strong {
      color: #343a40;
      font-size: 1.1rem;
    }

    .profile span {
      color: #6c757d;
      font-size: 0.9rem;
    }

    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .sidebar ul li {
      margin: 8px 0;
    }

    .sidebar ul li a {
      text-decoration: none;
      color: #495057;
      display: flex;
      align-items: center;
      padding: 12px 15px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
      background-color: #e9ecef;
      color: #6a11cb;
    }

    .sidebar ul li a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
      color: #6a11cb;
    }

    .sidebar ul li a.active {
      background-color: #e0d6f5;
      color: #6a11cb;
      font-weight: 500;
      border-left: 4px solid #6a11cb;
    }

    .main {
      margin-left: 270px;
      padding: 20px;
    }

    .table {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }

    .table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }
  </style>
</head>
    <!-- Main content -->
    <div class="main p-4">
      <h1 class="mb-4">Edit Book</h1>
      <form method="POST">
        <div class="mb-3">
          <label for="title" class="form-label">Title</label>
          <input type="text" class="form-control" id="title" name="title" value="<?= htmlspecialchars($book['title']) ?>" required>
        </div>
        <div class="mb-3">
          <label for="author" class="form-label">Author</label>
          <input type="text" class="form-control" id="author" name="author" value="<?= htmlspecialchars($book['author']) ?>" required>
        </div>
        <div class="mb-3">
          <label for="genre" class="form-label">Genre</label>
          <input type="text" class="form-control" id="genre" name="genre" value="<?= htmlspecialchars($book['genre']) ?>" required>
        </div>
        <div class="mb-3">
          <label for="qty" class="form-label">Quantity</label>
          <input type="number" class="form-control" id="qty" name="qty" value="<?= htmlspecialchars($book['quantity']) ?>" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Update Book</button>
      </form>
    </div>
  </div>
</body>
</html>
