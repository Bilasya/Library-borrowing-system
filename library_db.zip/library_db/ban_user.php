<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $banned_until = date('Y-m-d H:i:s', strtotime('+7 days'));

    $query = "UPDATE users SET banned_until = '$banned_until' WHERE id = $id AND role != 'admin'";
    if (mysqli_query($conn, $query)) {
        header("Location: manage.php?message=Banned successfully");
        exit;
    } else {
        echo "Error banning user: " . mysqli_error($conn);
    }
}
?>
